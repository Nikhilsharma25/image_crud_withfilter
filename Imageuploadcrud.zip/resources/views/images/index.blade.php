<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body >
      @if(session('status'))
        <h1 class="alert alert-success">{{session('status')}}</h1>
      @endif

     <div class="container" style="margin-top: 5px;">
      <a href="{{route('images.create')}}" class="btn btn-primary ">Add Image</a>
      <form method="POST" action="{{url('datefilter')}}">
        @csrf
          <input type="date" name="from_date" required>
          <input type="date" name="to_date" required>
          <button type="submit" class="btn btn-primary">Search</button>
      </form>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Image</th>
          <th scope="col">Action</th>
       
        </tr>
      </thead>
      <?php  $count = 1;?>
      <tbody>
        @foreach($Images as $Image)
        <tr>
            <td scope="row">{{$count ++}}</td> 
          <td> <img src="{{asset('uploads/images/'.@$Image->image_upload)}}" width="50px;" height="50px;"></td>        
          <td>
            <a href="{{route('images.edit',@$Image->id)}}" class="btn btn-primary">Edit</a>
            <a href="{{route('images.destroy',@$Image->id)}}" class="btn btn-danger">Delete</a>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
</div>
</body>
</html>